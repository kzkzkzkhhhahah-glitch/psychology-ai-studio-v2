package com.psychology.aistudio;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PICK_CHARACTER = 101;
    private ImageView characterPreview;
    private TextView characterStatus;
    private SharedPreferences prefs;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, float size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setPadding(dp(2),dp(2),dp(2),dp(2));
        return t;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("studio", MODE_PRIVATE);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(28),dp(22),dp(24));
        root.setBackgroundColor(Color.rgb(16,17,22));

        TextView title = text("Psychology AI Studio",28);
        title.setTypeface(null,1);
        root.addView(title);

        TextView subtitle = text("Create professional 2D psychology videos with your saved character.",16);
        subtitle.setTextColor(Color.LTGRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin = dp(8);
        root.addView(subtitle,sp);

        TextView topicLabel = text("VIDEO TOPIC",14);
        topicLabel.setTypeface(null,1);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.topMargin = dp(30);
        root.addView(topicLabel,lp);

        EditText topic = new EditText(this);
        topic.setHint("Example: Why do people overthink?");
        topic.setHintTextColor(Color.GRAY);
        topic.setTextColor(Color.WHITE);
        topic.setGravity(Gravity.TOP);
        topic.setMinHeight(dp(130));
        topic.setBackgroundColor(Color.rgb(29,31,40));
        topic.setPadding(dp(16),dp(16),dp(16),dp(16));
        root.addView(topic,new LinearLayout.LayoutParams(-1,dp(140)));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button voice = new Button(this);
        voice.setText("VOICE COMMAND");
        Button create = new Button(this);
        create.setText("CREATE VIDEO");
        buttons.addView(voice,new LinearLayout.LayoutParams(0,dp(62),1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,dp(62),1);
        cp.leftMargin = dp(10);
        buttons.addView(create,cp);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,dp(62));
        bp.topMargin = dp(20);
        root.addView(buttons,bp);

        TextView info = text("Online AI • 2D Character • Natural English Voice",14);
        info.setTextColor(Color.LTGRAY);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1,-2);
        ip.topMargin = dp(18);
        root.addView(info,ip);

        TextView charTitle = text("MASTER CHARACTER",14);
        charTitle.setTypeface(null,1);
        LinearLayout.LayoutParams ctp = new LinearLayout.LayoutParams(-1,-2);
        ctp.topMargin = dp(24);
        root.addView(charTitle,ctp);

        characterPreview = new ImageView(this);
        characterPreview.setBackgroundColor(Color.rgb(29,31,40));
        characterPreview.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        characterPreview.setPadding(dp(8),dp(8),dp(8),dp(8));
        LinearLayout.LayoutParams img = new LinearLayout.LayoutParams(-1,dp(220));
        img.topMargin = dp(8);
        root.addView(characterPreview,img);

        Button choose = new Button(this);
        choose.setText("CHOOSE / CHANGE MASTER CHARACTER");
        LinearLayout.LayoutParams ch = new LinearLayout.LayoutParams(-1,dp(56));
        ch.topMargin = dp(10);
        root.addView(choose,ch);

        characterStatus = text("",14);
        characterStatus.setTextColor(Color.LTGRAY);
        LinearLayout.LayoutParams cs = new LinearLayout.LayoutParams(-1,-2);
        cs.topMargin = dp(8);
        root.addView(characterStatus,cs);

        TextView youtube = text("YouTube: Not connected",14);
        youtube.setTextColor(Color.LTGRAY);
        LinearLayout.LayoutParams yt = new LinearLayout.LayoutParams(-1,-2);
        yt.topMargin = dp(8);
        root.addView(youtube,yt);

        choose.setOnClickListener(v -> pickCharacter());
        voice.setOnClickListener(v -> Toast.makeText(this,"Voice command will be connected in the next phase.",Toast.LENGTH_SHORT).show());
        create.setOnClickListener(v -> {
            if (!hasCharacter()) {
                Toast.makeText(this,"First save the Master Character.",Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this,"Video generation is the next phase.",Toast.LENGTH_SHORT).show();
        });

        loadSavedCharacter();
        setContentView(root);
    }

    private boolean hasCharacter() {
        return !prefs.getString("character_uri", "").isEmpty() || prefs.getBoolean("default_character_active", false);
    }

    private void pickCharacter() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_CHARACTER);
    }

    private void loadSavedCharacter() {
        String s = prefs.getString("character_uri", "");
        if (!s.isEmpty()) {
            try {
                characterPreview.setImageURI(Uri.parse(s));
                characterStatus.setText("Master Character: Saved & Active ✓");
                return;
            } catch(Exception ignored) {}
        }
        characterPreview.setImageResource(com.psychology.aistudio.R.drawable.master_character);
        characterStatus.setText("Master Character: Default character ready ✓");
        prefs.edit().putBoolean("default_character_active", true).apply();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_CHARACTER && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri u=data.getData();
            try { getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            prefs.edit().putString("character_uri",u.toString()).putBoolean("default_character_active",false).apply();
            characterPreview.setImageURI(u);
            characterStatus.setText("Master Character: Saved & Active ✓");
            Toast.makeText(this,"Master character saved. This reference will be used for future scenes.",Toast.LENGTH_SHORT).show();
        }
    }
}
