package com.psychology.aistudio;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); return t;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        int bg = Color.rgb(15,17,22), white = Color.WHITE, muted = Color.rgb(170,175,185), card = Color.rgb(28,31,39), accent = Color.rgb(120,100,255);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(28),dp(20),dp(20)); root.setBackgroundColor(bg);
        TextView title = text("Psychology AI Studio", 27, white, true); root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text("Create professional 2D psychology videos with your saved character.", 15, muted, false); sub.setPadding(0,dp(6),0,dp(22)); root.addView(sub);
        TextView label = text("VIDEO TOPIC", 12, muted, true); root.addView(label);
        EditText topic = new EditText(this); topic.setHint("Example: Why do people overthink?"); topic.setHintTextColor(Color.rgb(120,125,135)); topic.setTextColor(white); topic.setSingleLine(false); topic.setMinLines(3); topic.setGravity(Gravity.TOP); topic.setPadding(dp(14),dp(12),dp(14),dp(12)); topic.setBackgroundColor(card); LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1,dp(110)); ep.setMargins(0,dp(8),0,dp(16)); root.addView(topic,ep);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button voice = new Button(this); voice.setText("🎙 Voice Command"); row.addView(voice,new LinearLayout.LayoutParams(0,dp(52),1));
        Space sp = new Space(this); row.addView(sp,new LinearLayout.LayoutParams(dp(10),1));
        Button create = new Button(this); create.setText("Create Video"); create.setTextColor(white); create.setBackgroundColor(accent); row.addView(create,new LinearLayout.LayoutParams(0,dp(52),1)); root.addView(row);
        TextView status = text("\nOnline AI • 2D Character • Natural English Voice\n\nMaster Character: Not set yet\nYouTube: Not connected", 14, muted, false); root.addView(status,new LinearLayout.LayoutParams(-1,-2));
        create.setOnClickListener(v -> { String q=topic.getText().toString().trim(); if(q.isEmpty()) q="your psychology topic"; status.setText("\nProject ready: "+q+"\n\nNext: connect the secure online AI pipeline and Master Character."); });
        voice.setOnClickListener(v -> Toast.makeText(this,"Voice command will be connected in the next build stage.",Toast.LENGTH_SHORT).show());
        setContentView(root);
    }
}
