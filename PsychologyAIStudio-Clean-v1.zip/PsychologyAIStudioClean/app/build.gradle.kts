plugins { id("com.android.application") }

android {
    namespace = "com.psychology.aistudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.psychology.aistudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
